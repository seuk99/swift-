//
//  ViewController.swift
//  memo
//
//  Created by 강민석 on 2022/06/14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

